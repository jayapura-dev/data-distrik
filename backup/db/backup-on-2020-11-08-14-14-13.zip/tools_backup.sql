#
# TABLE STRUCTURE FOR: tb_distrik
#

DROP TABLE IF EXISTS `tb_distrik`;

CREATE TABLE `tb_distrik` (
  `id_distrik` int(14) NOT NULL,
  `id_wp` int(14) NOT NULL,
  `distrik` varchar(128) CHARACTER SET utf8 NOT NULL,
  `id_type` int(2) NOT NULL,
  `id_distrik_siopapua` int(10) NOT NULL,
  PRIMARY KEY (`id_distrik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (1, 2, 'DEPAPRE', 1, 97);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (4, 2, 'RAVENIRARA', 1, 109);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (5, 1, 'SENTANI', 1, 4);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (6, 2, 'SENTANI BARAT', 1, 98);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (7, 1, 'SENTANI TIMUR', 1, 96);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (8, 3, 'KEMTUK', 1, 99);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (9, 3, 'KEMTUK GRESI', 1, 5);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (10, 3, 'GRESI SELATAN', 1, 110);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (11, 3, 'NIMBORAN', 1, 6);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (12, 3, 'NIMBOKRANG', 1, 100);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (13, 3, 'NAMBLONG', 1, 106);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (14, 4, 'UNURUMGUAY', 2, 101);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (15, 4, 'YAPSI', 2, 107);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (16, 4, 'KAUREH', 1, 103);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (17, 4, 'AIRU', 2, 108);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (18, 1, 'WAIBU', 1, 105);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (19, 1, 'EBUNGFAUW', 1, 104);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (20, 2, 'DEMTA', 1, 102);
INSERT INTO `tb_distrik` (`id_distrik`, `id_wp`, `distrik`, `id_type`, `id_distrik_siopapua`) VALUES (21, 2, 'YOKARI', 1, 111);


#
# TABLE STRUCTURE FOR: tb_familiy
#

DROP TABLE IF EXISTS `tb_familiy`;

CREATE TABLE `tb_familiy` (
  `id_fam` int(10) NOT NULL AUTO_INCREMENT,
  `id_distrik` int(10) NOT NULL,
  `id_kampung` int(10) NOT NULL,
  `nama_kk` varchar(100) NOT NULL,
  `nomor_kartu_keluarga` varchar(128) NOT NULL,
  `nomor_rumah` varchar(5) NOT NULL,
  `nomor_telfon` varchar(13) NOT NULL,
  `suku` varchar(10) NOT NULL,
  `rw` varchar(5) NOT NULL,
  `rt` varchar(5) NOT NULL,
  `penguasaan_bangunan` varchar(20) NOT NULL,
  `status_lahan` varchar(20) NOT NULL,
  `luas_lantai` varchar(10) NOT NULL,
  `jenis_lantai` varchar(30) NOT NULL,
  `kondisi_lantai` varchar(30) NOT NULL,
  `jenis_dinding` varchar(30) NOT NULL,
  `kondisi_dinding` varchar(30) NOT NULL,
  `jenis_atap` varchar(30) NOT NULL,
  `kondisi_atap` varchar(30) NOT NULL,
  `jumlah_kamar` decimal(10,0) NOT NULL,
  `sumber_air_minum` varchar(20) NOT NULL,
  `peroleh_air_minum` varchar(20) NOT NULL,
  `ketersediaan_air` varchar(30) NOT NULL,
  `sumber_penerangan` varchar(20) NOT NULL,
  `energi_memasak` varchar(20) NOT NULL,
  `daya_pln` varchar(5) NOT NULL,
  `fasilitas_buang_air` varchar(10) NOT NULL,
  `penggunaan_jamban` varchar(30) NOT NULL,
  `pembuangan_air` varchar(15) NOT NULL,
  PRIMARY KEY (`id_fam`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tb_familiy` (`id_fam`, `id_distrik`, `id_kampung`, `nama_kk`, `nomor_kartu_keluarga`, `nomor_rumah`, `nomor_telfon`, `suku`, `rw`, `rt`, `penguasaan_bangunan`, `status_lahan`, `luas_lantai`, `jenis_lantai`, `kondisi_lantai`, `jenis_dinding`, `kondisi_dinding`, `jenis_atap`, `kondisi_atap`, `jumlah_kamar`, `sumber_air_minum`, `peroleh_air_minum`, `ketersediaan_air`, `sumber_penerangan`, `energi_memasak`, `daya_pln`, `fasilitas_buang_air`, `penggunaan_jamban`, `pembuangan_air`) VALUES (1, 4, 6, 'Yohosua Isak Ormuseray', '9103021503120004', '2', '085344367855', 'OAP', '002', '001', 'Milik Sendiri', 'Milik Sendiri', '200', 'semen', 'bagus, kualitas rendah', 'tembok', 'Bagus, kualitas tinggi', 'Seng', 'Bagus, kualitas rendah', '2', 'Kali', 'Tidak Membeli', 'Sepanjang tahun', 'Listrik PLN', 'Minyak tanah', '1300', 'Sendiri', 'Dipakai seluruh anggota keluar', 'Selokan');
INSERT INTO `tb_familiy` (`id_fam`, `id_distrik`, `id_kampung`, `nama_kk`, `nomor_kartu_keluarga`, `nomor_rumah`, `nomor_telfon`, `suku`, `rw`, `rt`, `penguasaan_bangunan`, `status_lahan`, `luas_lantai`, `jenis_lantai`, `kondisi_lantai`, `jenis_dinding`, `kondisi_dinding`, `jenis_atap`, `kondisi_atap`, `jumlah_kamar`, `sumber_air_minum`, `peroleh_air_minum`, `ketersediaan_air`, `sumber_penerangan`, `energi_memasak`, `daya_pln`, `fasilitas_buang_air`, `penggunaan_jamban`, `pembuangan_air`) VALUES (2, 4, 6, 'Viktor Serondanya', '9103021212121013', '3', '082199537593', 'OAP', '002', '001', 'Milik Sendiri', 'Milik Sendiri', '340', 'semen', 'bagus, kualitas rendah', 'tembok', 'Bagus, kualitas rendah', 'Seng', 'Bagus, kualitas tinggi', '2', 'Kali', 'Tidak Membeli', 'Sepanjang tahun', 'Listrik PLN', 'Minyak tanah', '1800', 'Sendiri', 'Dipakai seluruh anggota keluar', 'Selokan');


#
# TABLE STRUCTURE FOR: tb_index_distrik
#

DROP TABLE IF EXISTS `tb_index_distrik`;

CREATE TABLE `tb_index_distrik` (
  `id_dis_index` int(2) NOT NULL,
  `id_distrik` int(2) NOT NULL,
  PRIMARY KEY (`id_dis_index`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tb_index_distrik` (`id_dis_index`, `id_distrik`) VALUES (1, 1);


#
# TABLE STRUCTURE FOR: tb_kampung
#

DROP TABLE IF EXISTS `tb_kampung`;

CREATE TABLE `tb_kampung` (
  `id_kampung` int(14) NOT NULL AUTO_INCREMENT,
  `id_distrik` int(14) NOT NULL,
  `kampung` varchar(128) CHARACTER SET utf8 NOT NULL,
  `id_kakam` int(10) NOT NULL,
  `sekam` varchar(50) NOT NULL,
  `id_kamp_siopapua` int(10) NOT NULL,
  PRIMARY KEY (`id_kampung`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (1, 1, 'Dormena', 2, '-', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (2, 6, 'Maribu', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (3, 6, 'Dosay', 1, '-', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (4, 1, 'Yewena', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (5, 4, 'Yongsu Spari', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (6, 4, 'Yongsu Desoyo', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (7, 20, 'Demta Kota', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (8, 20, 'Yaugabsa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (9, 20, 'Muris kecil', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (10, 20, 'Yakore', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (11, 20, 'Ambora', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (12, 20, 'Kamdera', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (13, 20, 'Muaif', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (14, 1, 'Kendate', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (15, 1, 'Wambena', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (17, 1, 'Yepase', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (18, 1, 'Waiya', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (19, 1, 'Nusu', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (20, 1, 'Supa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (21, 17, 'Muara Nawa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (22, 17, 'Aurina', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (23, 17, 'Pagai', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (24, 17, 'Kamikaru', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (25, 17, 'Naira', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (26, 21, 'Meukisi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (27, 21, 'Endokisi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (28, 21, 'Snamai', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (29, 21, 'Maruwai', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (30, 6, 'Sabron', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (31, 6, 'Sabron Sari', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (32, 6, 'Waibron', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (33, 19, 'Abar', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (34, 19, 'Babrongkho', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (35, 19, 'Ebungfa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (36, 19, 'Khameyaka', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (37, 19, 'Simporo', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (38, 16, 'Lapua', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (39, 16, 'Sebum', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (40, 16, 'Soskotek', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (41, 16, 'Umbron', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (42, 16, 'Yadaouw', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (43, 8, 'Aib', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (44, 8, 'Bengguin Progo', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (45, 8, 'Kwansu', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (46, 8, 'Mamda', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (47, 8, 'Mamda yawan', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (48, 8, 'Nambon', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (49, 8, 'Namei', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (50, 8, 'Sebeab Kecil', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (51, 8, 'Sama', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (52, 8, 'Sekori', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (53, 8, 'Skoaim', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (54, 8, 'Soaib', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (55, 9, 'Braso', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (56, 9, 'Bring', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (57, 9, 'Damoi Kati', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (58, 9, 'Demetin', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (59, 9, 'Hatib', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (60, 9, 'Ibub', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (61, 9, 'Jangrang', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (62, 9, 'Nembu Gresi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (63, 9, 'Omon', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (64, 9, 'Pupehabu', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (65, 9, 'Swetab', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (66, 9, 'Yanbra', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (67, 12, 'Benyom Jaya I', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (68, 12, 'Benyom Jaya II', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (69, 12, 'Berap', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (70, 12, 'Benyom', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (71, 12, 'Hamongkrang', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (72, 12, 'Nimbokrang', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (73, 12, 'Nimbokrang Sari', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (74, 12, 'Rhepang Muaif', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (75, 11, 'Benyom', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (76, 11, 'Gemebs', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (77, 11, 'Imsar', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (78, 11, 'Kaitemung', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (79, 11, 'Kuipons', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (80, 11, 'Kuwase', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (81, 11, 'Meyu', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (82, 11, 'Oyengsi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (83, 11, 'Pobaim', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (84, 11, 'Singgri', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (85, 11, 'Singgriway', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (86, 11, 'Tabri', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (87, 11, 'Yenggu Lama', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (88, 11, 'Yenggu Baru', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (89, 13, 'Besum', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (90, 13, 'Hanggai Hamong', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (91, 13, 'Imestum', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (92, 13, 'Karya Bumi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (93, 13, 'Sanggai', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (94, 13, 'Sarmai Atas', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (95, 13, 'Sarmai Bawah', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (96, 13, 'Sumbe', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (97, 13, 'Yakasib', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (98, 5, 'Dobonsolo', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (99, 5, 'Hinekombe', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (100, 5, 'Hobong', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (101, 5, 'Ifale', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (102, 5, 'Ifar Besar', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (103, 5, 'Kehiran', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (104, 5, 'Sereh', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (105, 5, 'Yobeh', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (106, 5, 'Yoboy', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (107, 7, 'Asai Besar', 0, '', 628);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (108, 7, 'Asai Kecil', 0, '', 629);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (109, 7, 'Ayapo', 0, '', 627);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (110, 7, 'Nendali', 0, '', 630);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (111, 7, 'Nolokla', 0, '', 625);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (112, 7, 'Puay', 0, '', 626);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (113, 7, 'Yokiwa', 0, '', 631);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (114, 14, 'Beniek', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (115, 14, 'Garusa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (116, 14, 'Guriad', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (117, 14, 'Nendalzi', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (118, 14, 'Sawesuma', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (119, 14, 'Sentosa', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (120, 18, 'Bambar', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (121, 18, 'Dondai', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (122, 18, 'Doyo baru', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (123, 18, 'Doyo lama', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (124, 18, 'Kwadeware', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (125, 18, 'Sosiri', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (126, 18, 'Yakonde', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (127, 15, 'Bumi Sahaja', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (128, 15, 'Bundru', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (129, 15, 'Kwarja', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (130, 15, 'Nawa Mukti', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (131, 15, 'Nawa Mulya', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (132, 15, 'Ongan jaya', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (133, 15, 'Purnawajati', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (134, 15, 'Tabbeyan', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (135, 15, 'Taqwa bangun', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (136, 21, 'Buseryo', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (137, 5, 'Sentani Kota', 0, '', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (138, 4, 'Necheibe', 0, '-', 0);
INSERT INTO `tb_kampung` (`id_kampung`, `id_distrik`, `kampung`, `id_kakam`, `sekam`, `id_kamp_siopapua`) VALUES (139, 4, 'Ormuwari', 0, '-', 0);


#
# TABLE STRUCTURE FOR: tb_member
#

DROP TABLE IF EXISTS `tb_member`;

CREATE TABLE `tb_member` (
  `id_member` int(10) NOT NULL AUTO_INCREMENT,
  `id_fam` int(10) NOT NULL,
  `id_kampung` int(10) NOT NULL,
  `no_urut` int(10) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `nik` varchar(128) NOT NULL,
  `suku` varchar(10) NOT NULL,
  `golongan_darah` varchar(10) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `nama_ayah` varchar(40) NOT NULL,
  `status_perkawinan` varchar(20) NOT NULL,
  `adminduk_ktp` varchar(10) NOT NULL,
  `adminduk_akta_lahir` varchar(10) NOT NULL,
  `pekerjaan` varchar(40) NOT NULL,
  `ijazah_terahir` varchar(20) NOT NULL,
  `partisipasi_sekolah` varchar(30) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `hub_kk` varchar(40) NOT NULL,
  `id_distrik` int(10) NOT NULL,
  PRIMARY KEY (`id_member`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tb_member` (`id_member`, `id_fam`, `id_kampung`, `no_urut`, `nama`, `nik`, `suku`, `golongan_darah`, `tempat_lahir`, `tgl_lahir`, `nama_ayah`, `status_perkawinan`, `adminduk_ktp`, `adminduk_akta_lahir`, `pekerjaan`, `ijazah_terahir`, `partisipasi_sekolah`, `agama`, `hub_kk`, `id_distrik`) VALUES (2, 1, 6, NULL, 'Michel Ormuseray', '9103100502600002', 'OAP', 'AB', 'Jayapura', '2014-01-01', 'Yohosua Isak', 'Belum kawin', 'Tidak', 'Ya', 'Tidak bekerja', 'Tidak punya ijazah', 'Masih bersekolah', 'Kristen', 'Anak', 4);
INSERT INTO `tb_member` (`id_member`, `id_fam`, `id_kampung`, `no_urut`, `nama`, `nik`, `suku`, `golongan_darah`, `tempat_lahir`, `tgl_lahir`, `nama_ayah`, `status_perkawinan`, `adminduk_ktp`, `adminduk_akta_lahir`, `pekerjaan`, `ijazah_terahir`, `partisipasi_sekolah`, `agama`, `hub_kk`, `id_distrik`) VALUES (3, 2, 6, NULL, 'Blandina Dodop', '9103100502600004', 'OAP', 'A', 'Jayapura', '1986-06-17', 'Obet', 'Kawin', 'Ya', 'Ya', 'Pegawai Negri Sipil', 'Perguruan tinggi', 'Tidak bersekolah lagi', 'Kristen', 'Ibu', 4);
INSERT INTO `tb_member` (`id_member`, `id_fam`, `id_kampung`, `no_urut`, `nama`, `nik`, `suku`, `golongan_darah`, `tempat_lahir`, `tgl_lahir`, `nama_ayah`, `status_perkawinan`, `adminduk_ktp`, `adminduk_akta_lahir`, `pekerjaan`, `ijazah_terahir`, `partisipasi_sekolah`, `agama`, `hub_kk`, `id_distrik`) VALUES (5, 1, 6, NULL, 'Billy Ormuseray', '9103100502602003', 'OAP', 'B', 'Jayapura', '2010-05-04', 'Yohosua Isak', 'Belum kawin', 'Tidak', 'Ya', 'Tidak bekerja', 'Tidak punya ijazah', 'Belum bersekolah', 'Kristen', 'Anak', 4);


